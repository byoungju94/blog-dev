package com.byoungju94.blog.domain.category.dto;

public record CategoryCreateDTO(String name) {
}
