package com.byoungju94.blog.domain.comment;

public enum CommentState {
    
    CREATED, UPDATED, BLOCKED, DELETED
}
