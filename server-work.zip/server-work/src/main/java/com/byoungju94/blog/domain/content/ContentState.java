package com.byoungju94.blog.domain.content;

public enum ContentState {

    OPENED, BLOCKED, HIDDEN, DELETED
}
