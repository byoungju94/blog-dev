package com.byoungju94.blog.domain.comment.dto;

public record CommentDTO(String id, String content, String state, String createdAt) {
    
}
