package com.byoungju94.blog.domain.account.dto;

public record AccountReadDTO(String id, String username, String name, String status) {
}
