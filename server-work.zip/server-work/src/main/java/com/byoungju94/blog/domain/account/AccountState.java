package com.byoungju94.blog.domain.account;

public enum AccountState {
    ACTIVE, BLOCKED, DELETED
}
