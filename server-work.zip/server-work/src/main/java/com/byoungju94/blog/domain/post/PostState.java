package com.byoungju94.blog.domain.post;

public enum PostState {
    
    OPENED, BLOCKED, HIDDEN, DELETED
}
